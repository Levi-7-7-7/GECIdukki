// Name
// Roll Number
// Date


//#include<stdio.h> 
import java.lang.*;

class MyClass
{

	//void main()
	public static void main(String abc[])
	{
		int a = 10 ;
		int b = 20;
		int c = 30 ;
		
		int greatest = 0 ;
		
		if(a > b )
		{
			if(a> c)
			{
				greatest = a ;
			}
		}
		else
		{
			if(b > c)
			{
				greatest = b ;
			}
		}
		//printf("Greatest = %d", greatest);
		System.out.println("Greatest = " + greatest);
		
	}


}