public class CommandLineAddition {

    public static void main(String[] args) {

        /*
         * Command-line arguments are received
         * as String values.
         *
         * args[0] contains the first argument.
         * args[1] contains the second argument.
         */

        // Convert String arguments into integers
        int number1 = Integer.parseInt(args[0]);
        int number2 = Integer.parseInt(args[1]);

        // Add the two numbers
        int sum = number1 + number2;
		//int sum = args[0] + args[1]  ;

        // Display the result
        System.out.println("First Number  : " + args[0]);
        System.out.println("Second Number : " + args[1]);
        System.out.println("Sum           : " + sum);
    }
}