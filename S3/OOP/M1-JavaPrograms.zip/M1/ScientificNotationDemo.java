public class ScientificNotationDemo {

    public static void main(String[] args) {

        /*
         * Floating-point literals can be
         * written using scientific notation.
         *
         * e or E represents "10 raised to".
         */


        // 1.5 x 10^3
        double value1 = 1.5e3;


        // 2.5 x 10^4
        double value2 = 2.5E4;


        // 4.5 x 10^-3
        double value3 = 4.5e-3;


        System.out.println(
                "1.5e3  = " + value1
        );

        System.out.println(
                "2.5E4  = " + value2
        );

        System.out.println(
                "4.5e-3 = " + value3
        );
    }
}