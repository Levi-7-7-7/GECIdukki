public class AutoboxingTypesDemo {

    public static void main(String[] args) {

        /*
         * Each primitive type is automatically
         * converted into its corresponding
         * wrapper type.
         */


        byte byteValue = 10;

        Byte byteObject = byteValue;


        short shortValue = 100;

        Short shortObject = shortValue;


        int intValue = 1000;

        Integer intObject = intValue;


        long longValue = 10000L;

        Long longObject = longValue;


        float floatValue = 10.5F;

        Float floatObject = floatValue;


        double doubleValue = 25.75;

        Double doubleObject = doubleValue;


        char charValue = 'A';

        Character charObject = charValue;


        boolean booleanValue = true;

        Boolean booleanObject = booleanValue;


        System.out.println(
                "Byte      : " + byteObject
        );

        System.out.println(
                "Short     : " + shortObject
        );

        System.out.println(
                "Integer   : " + intObject
        );

        System.out.println(
                "Long      : " + longObject
        );

        System.out.println(
                "Float     : " + floatObject
        );

        System.out.println(
                "Double    : " + doubleObject
        );

        System.out.println(
                "Character : " + charObject
        );

        System.out.println(
                "Boolean   : " + booleanObject
        );
    }
}