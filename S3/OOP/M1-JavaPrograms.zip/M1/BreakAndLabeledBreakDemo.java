public class BreakAndLabeledBreakDemo {

    public static void main(String[] args) {

        /*
         * PART 1: Normal break
         *
         * break is used to immediately exit from a loop.
         */

        System.out.println("--- Normal break example ---");

        for (int i = 1; i <= 10; i++) {

            if (i == 5) {
                /*
                 * When i becomes 5, the loop stops.
                 * Control comes out of the for loop.
                 */
                break;
            }

            System.out.println("i = " + i);
        }

        System.out.println("Loop stopped when i became 5");


        /*
         * PART 2: Labeled break
         *
         * A labeled break is used to come out of
         * a specific outer loop from an inner loop.
         */

        System.out.println("\n--- Labeled break example ---");

        outerLoop:
        for (int row = 1; row <= 3; row++) {

            for (int col = 1; col <= 3; col++) {

                System.out.println("row = " + row + ", col = " + col);

                if (row == 2 && col == 2) {

                    /*
                     * Normal break would stop only
                     * the inner loop.
                     *
                     * But break outerLoop stops
                     * both inner and outer loops.
                     */
                    break outerLoop;
                }
            }
        }

        System.out.println("Exited from both loops using labeled break");
    }
}