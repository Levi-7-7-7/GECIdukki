public class PrimitiveCastingDemo {

    public static void main(String[] args) {

        // =====================================
        // 1. WIDENING CASTING
        // =====================================

        int number = 100;

        double doubleValue = number;

        System.out.println("--- WIDENING ---");

        System.out.println(
                "int value    : " + number
        );

        System.out.println(
                "double value : " + doubleValue
        );


        // =====================================
        // 2. NARROWING CASTING
        // =====================================

        double price = 125.75;

        int integerPrice = (int) price;

        System.out.println("\n--- NARROWING ---");

        System.out.println(
                "double value : " + price
        );

        System.out.println(
                "int value    : " + integerPrice
        );


        // =====================================
        // 3. CHAR TO INT
        // =====================================

        char letter = 'A';

        int characterValue = letter;

        System.out.println("\n--- CHAR TO INT ---");

        System.out.println(
                "Character : " + letter
        );

        System.out.println(
                "Value     : " + characterValue
        );


        // =====================================
        // 4. INT TO CHAR
        // =====================================

        int unicodeValue = 66;

        char character =
                (char) unicodeValue;

        System.out.println("\n--- INT TO CHAR ---");

        System.out.println(
                "Integer   : " + unicodeValue
        );

        System.out.println(
                "Character : " + character
        );


        // =====================================
        // 5. CASTING IN DIVISION
        // =====================================

        int total = 5;

        int count = 2;

        double result1 =
                total / count;

        double result2 =
                (double) total / count;


        System.out.println("\n--- DIVISION ---");

        System.out.println(
                "Without casting : " + result1
        );

        System.out.println(
                "With casting    : " + result2
        );


        // =====================================
        // 6. POSSIBLE DATA LOSS
        // =====================================

        int largeValue = 130;

        byte smallValue =
                (byte) largeValue;


        System.out.println("\n--- DATA LOSS ---");

        System.out.println(
                "Original int : " + largeValue
        );

        System.out.println(
                "byte value   : " + smallValue
        );
    }
}