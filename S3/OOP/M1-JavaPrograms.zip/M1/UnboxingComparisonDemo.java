public class UnboxingComparisonDemo {

    public static void main(String[] args) {

        Integer wrapperValue = 200;


        /*
         * MANUAL UNBOXING
         */

        int number1 =
                wrapperValue.intValue();


        /*
         * AUTOMATIC UNBOXING
         */

        int number2 = wrapperValue;


        System.out.println(
                "Manual Unboxing    : " + number1
        );

        System.out.println(
                "Automatic Unboxing : " + number2
        );
    }
}