public class NullUnboxingDemo {

    public static void main(String[] args) {

        /*
         * Wrapper types can store null.
         */

        Integer number = null;


        /*
         * The following statement attempts
         * to unbox number.
         *
         * Java internally tries to execute:
         *
         * number.intValue()
         *
         * But number is null.
         *
         * Therefore, a NullPointerException occurs.
         */

        int value = number;


        System.out.println(
                "Value: " + value
        );
    }
}