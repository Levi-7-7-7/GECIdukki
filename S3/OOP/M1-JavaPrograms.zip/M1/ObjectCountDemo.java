public class ObjectCountDemo {

    // Static variable shared by all objects
    static int objectCount = 0;

    // Constructor
    ObjectCountDemo() {
        objectCount++;  // Increment count whenever object is created
    }

    public static void main(String[] args) {

        ObjectCountDemo obj1 = new ObjectCountDemo();
        ObjectCountDemo obj2 = new ObjectCountDemo();
        ObjectCountDemo obj3 = new ObjectCountDemo();

        System.out.println("Number of objects created: " + ObjectCountDemo.objectCount);
    }
}