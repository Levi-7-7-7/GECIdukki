import java.util.ArrayList;

public class WrapperNeedDemo {

    public static void main(String[] args) {

        /*
         * ArrayList stores objects.
         *
         * Therefore, primitive types such as int
         * cannot be directly used as the type
         * parameter of ArrayList.
         */


        /*
         * INVALID:
         *
         * ArrayList<int> numbers =
         *         new ArrayList<int>();
         *
         * int is a primitive type.
         */


        /*
         * Integer is a wrapper class.
         *
         * Therefore, it can be used
         * with ArrayList.
         */

        ArrayList<Integer> numbers =
                new ArrayList<Integer>();


        numbers.add(10);
        numbers.add(20);
        numbers.add(30);


        System.out.println(
                "Numbers: " + numbers
        );


        System.out.println(
                "First Number: " + numbers.get(0)
        );
    }
}