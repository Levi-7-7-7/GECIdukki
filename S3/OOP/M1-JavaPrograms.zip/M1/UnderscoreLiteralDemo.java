public class UnderscoreLiteralDemo {

    public static void main(String[] args) {

        /*
         * Java allows underscores inside
         * numeric literals.
         *
         * They improve readability.
         */

        int salary = 1_00_000;

        long population = 1_400_000_000L;

        double amount = 12_345.75;


        System.out.println(
                "Salary     : " + salary
        );

        System.out.println(
                "Population : " + population
        );

        System.out.println(
                "Amount     : " + amount
        );


        /*
         * The underscore does not affect
         * the actual numeric value.
         */

        int number1 = 100000;

        int number2 = 100_000;

        System.out.println(
                "Are values equal? "
                + (number1 == number2)
        );
    }
}