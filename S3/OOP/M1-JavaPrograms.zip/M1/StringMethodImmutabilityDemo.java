public class StringMethodImmutabilityDemo {

    public static void main(String[] args) {

        String text = "hello";

        /*
         * toUpperCase() creates a new String.
         * It does not modify the original String.
         */

        text.toUpperCase();

        System.out.println("After toUpperCase without assignment: " + text);

        /*
         * Now we store the newly created String
         * into another variable.
         */

        String upperText = text.toUpperCase();

        System.out.println("Original String : " + text);
        System.out.println("New String      : " + upperText);
    }
}