import java.util.ArrayList;

public class ArrayListDemo {

    public static void main(String[] args) {

        /*
         * ArrayList is a resizable array.
         *
         * Normal arrays have fixed size.
         * ArrayList can grow or shrink during program execution.
         */

        // Creating an ArrayList to store student names
        ArrayList<String> students = new ArrayList<String>();

        // Adding elements to the ArrayList
        students.add("Arun");
        students.add("Anu");
        students.add("Rahul");
        students.add("Meera");

        System.out.println("Initial ArrayList: " + students);

        /*
         * Accessing elements
         * Index starts from 0.
         */

        System.out.println("First student: " + students.get(0));
        System.out.println("Second student: " + students.get(1));

        /*
         * Adding an element at a specific index
         */

        students.add(2, "John");

        System.out.println("After adding John at index 2: " + students);

        /*
         * Updating an element
         */

        students.set(0, "Arjun");

        System.out.println("After updating first student: " + students);

        /*
         * Removing an element
         */

        students.remove("Rahul");

        System.out.println("After removing Rahul: " + students);

        /*
         * Checking whether an element exists
         */

        if (students.contains("Anu")) {
            System.out.println("Anu is present in the ArrayList");
        } else {
            System.out.println("Anu is not present in the ArrayList");
        }

        /*
         * Displaying the size of ArrayList
         */

        System.out.println("Size of ArrayList: " + students.size());

        /*
         * Traversing ArrayList using normal for loop
         */

        System.out.println("\nStudents using normal for loop:");

        for (int i = 0; i < students.size(); i++) {
            System.out.println(students.get(i));
        }

        /*
         * Traversing ArrayList using enhanced for loop
         */

        System.out.println("\nStudents using enhanced for loop:");

        for (String student : students) {
            System.out.println(student);
        }

        /*
         * Removing all elements
         */

        students.clear();

        System.out.println("\nAfter clearing ArrayList: " + students);
        System.out.println("Is ArrayList empty? " + students.isEmpty());
    }
}