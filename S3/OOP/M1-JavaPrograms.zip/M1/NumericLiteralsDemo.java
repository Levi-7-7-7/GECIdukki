public class NumericLiteralsDemo {

    public static void main(String[] args) {

        /*
         * Whole number literals are int by default.
         *
         * L or l is used to represent a long literal.
         */

        long distance = 9876543210L;

        System.out.println(
                "Long Literal: " + distance
        );


        /*
         * Decimal literals are double by default.
         *
         * F or f is required for float literals.
         */

        float price = 125.50F;

        double amount = 9876.75;


        System.out.println(
                "Float Literal : " + price
        );

        System.out.println(
                "Double Literal: " + amount
        );


        /*
         * D or d may also be used for double.
         *
         * However, it is optional.
         */

        double value1 = 25.5;

        double value2 = 25.5D;


        System.out.println(
                "Double without D: " + value1
        );

        System.out.println(
                "Double with D   : " + value2
        );
    }
}