public class WideningCastingDemo {

    public static void main(String[] args) {

        /*
         * WIDENING TYPE CASTING
         *
         * A value of a smaller data type is
         * converted into a larger data type.
         *
         * This conversion is automatic.
         *
         * General order:
         *
         * byte -> short -> int -> long -> float -> double
         */

        byte byteValue = 100;

        // byte is automatically converted to short
        short shortValue = byteValue;

        // short is automatically converted to int
        int intValue = shortValue;

        // int is automatically converted to long
        long longValue = intValue;

        // long is automatically converted to float
        float floatValue = longValue;

        // float is automatically converted to double
        double doubleValue = floatValue;


        System.out.println("byte value   : " + byteValue);
        System.out.println("short value  : " + shortValue);
        System.out.println("int value    : " + intValue);
        System.out.println("long value   : " + longValue);
        System.out.println("float value  : " + floatValue);
        System.out.println("double value : " + doubleValue);
    }
}