public class StringImmutabilityDemo {

    public static void main(String[] args) {

        /*
         * Strings in Java are immutable.
         *
         * Immutable means:
         * Once a String object is created,
         * its content cannot be changed.
         */

        String name = "Java";

        System.out.println("Original String: " + name);

        /*
         * concat() does not modify the original String.
         * Instead, it creates a new String object.
         */

        name.concat(" Programming");

        /*
         * The original string remains unchanged
         * because String is immutable.
         */

        System.out.println("After concat without assignment: " + name);

        /*
         * To store the changed value, we must assign
         * the new String object back to the variable.
         */

        name = name.concat(" Programming");

        System.out.println("After concat with assignment: " + name);
    }
}