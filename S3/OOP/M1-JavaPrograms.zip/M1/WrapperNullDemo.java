public class WrapperNullDemo {

    public static void main(String[] args) {

        /*
         * Primitive types cannot store null.
         *
         * INVALID:
         *
         * int mark = null;
         */


        /*
         * Wrapper types are object types.
         *
         * Therefore, they can store null.
         */

        Integer mark = null;


        System.out.println(
                "Mark: " + mark
        );


        /*
         * null can represent:
         *
         * Value not available
         * Value not entered
         * Value not assigned
         */


        if (mark == null) {

            System.out.println(
                    "Mark has not been entered"
            );

        } else {

            System.out.println(
                    "Mark is " + mark
            );
        }
    }
}