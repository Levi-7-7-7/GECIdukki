public class VarargsDemo {

    /*
     * Variable arguments allow a method to accept
     * any number of arguments of the same type.
     *
     * Syntax:
     * dataType... variableName
     *
     * Here, int... numbers means this method can receive
     * zero, one, or many integer values.
     */

    static void addNumbers(int... numbers) {

        int sum = 0;

        /*
         * Internally, varargs are treated like an array.
         * So we can use enhanced for loop to access values.
         */

        for (int number : numbers) {
            sum = sum + number;
        }

        System.out.println("Number of arguments: " + numbers.length);
        System.out.println("Sum: " + sum);
        System.out.println();
    }

    public static void main(String[] args) {

        /*
         * Same method is called with different
         * number of arguments.
         */

        addNumbers(10, 20);

        addNumbers(10, 20, 30);

        addNumbers(5, 10, 15, 20, 25);

        addNumbers();   // Method can also be called with no arguments
    }
}