public class PrimitiveAndWrapperDemo {

    public static void main(String[] args) {

        /*
         * Primitive data type
         *
         * int stores a simple integer value.
         */
        int number = 100;


        /*
         * Wrapper type
         *
         * Integer is the wrapper class
         * corresponding to int.
         */
        Integer wrapperNumber = 100;

        System.out.println(
                "Primitive int value : " + number
        );

        System.out.println(
                "Wrapper Integer value : " + wrapperNumber
        );
    }
}