// Name
// Roll Number
// Date

// This is a single line comment

/*  This 
      is 
	  a 
	  multiple line comment */
	  
	  /** This is a sample program for S3 CSE */
	  

//#include<stdio.h> - To include
import java.lang.*;

public class HelloWorld
{
	static int year = 2026 ;
	//void main()
	public static void main(String args[])
	{
		//printf("Hello World!");
		System.out.println("Hello World! " + year);
	}


}