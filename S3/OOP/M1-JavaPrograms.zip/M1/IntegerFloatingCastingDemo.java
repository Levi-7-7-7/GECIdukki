public class IntegerFloatingCastingDemo {

    public static void main(String[] args) {

        // --------------------------------
        // int to double
        // --------------------------------

        int marks = 95;

        /*
         * int to double is widening.
         */

        double doubleMarks = marks;


        System.out.println(
                "int value    : " + marks
        );

        System.out.println(
                "double value : " + doubleMarks
        );


        // --------------------------------
        // double to int
        // --------------------------------

        double average = 87.95;

        /*
         * double to int is narrowing.
         */

        int integerAverage = (int) average;


        System.out.println(
                "\nOriginal average : " + average
        );

        System.out.println(
                "Integer average  : " + integerAverage
        );


        // --------------------------------
        // float to int
        // --------------------------------

        float temperature = 36.8F;

        int integerTemperature =
                (int) temperature;


        System.out.println(
                "\nTemperature        : " + temperature
        );

        System.out.println(
                "Integer temperature: "
                        + integerTemperature
        );
    }
}