public class CharCastingDemo {

    public static void main(String[] args) {

        /*
         * char stores a Unicode character.
         *
         * A char value can be converted
         * into an integer value.
         */


        char letter = 'A';


        /*
         * char to int is a widening conversion.
         *
         * The Unicode value of the character
         * is stored in the integer variable.
         */

        int unicodeValue = letter;


        System.out.println(
                "Character     : " + letter
        );

        System.out.println(
                "Unicode value : " + unicodeValue
        );


        // --------------------------------
        // int to char
        // --------------------------------

        int number = 66;


        /*
         * int to char requires explicit casting.
         */

        char character = (char) number;


        System.out.println(
                "\nInteger value : " + number
        );

        System.out.println(
                "Character     : " + character
        );
    }
}