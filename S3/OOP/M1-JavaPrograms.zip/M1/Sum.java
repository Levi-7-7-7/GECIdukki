// Name
// Roll Number
// Date


//#include<stdio.h> 
import java.lang.*;

class Sum
{

	//void main()
	public static void main(String abc[])
	{
		int a = 10 ;
		int b = 20;
		int sum = a + b ;
		//printf("Sum = %d", sum);
		System.out.println("Sum = " + sum);
		
	}


}