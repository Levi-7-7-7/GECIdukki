public class WrapperMethodsDemo {

    public static void main(String[] args) {

        /*
         * Primitive variables only store values.
         *
         * Wrapper classes provide
         * useful methods and constants.
         */


        String numberText = "250";


        /*
         * Integer.parseInt()
         *
         * Converts a String into int.
         */

        int number =
                Integer.parseInt(numberText);


        System.out.println(
                "Converted Number: " + number
        );


        /*
         * Integer.MAX_VALUE
         *
         * Maximum value that can be
         * stored in an int.
         */

        System.out.println(
                "Maximum int value: "
                        + Integer.MAX_VALUE
        );


        /*
         * Integer.MIN_VALUE
         *
         * Minimum value that can be
         * stored in an int.
         */

        System.out.println(
                "Minimum int value: "
                        + Integer.MIN_VALUE
        );


        /*
         * Integer.toBinaryString()
         *
         * Converts an integer into
         * binary representation.
         */

        System.out.println(
                "Binary of 10: "
                        + Integer.toBinaryString(10)
        );


        /*
         * Integer.toHexString()
         *
         * Converts an integer into
         * hexadecimal representation.
         */

        System.out.println(
                "Hexadecimal of 255: "
                        + Integer.toHexString(255)
        );
    }
}