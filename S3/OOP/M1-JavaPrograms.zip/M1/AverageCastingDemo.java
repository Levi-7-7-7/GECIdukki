public class AverageCastingDemo {

    public static void main(String[] args) {

        int mark1 = 85;

        int mark2 = 90;

        int mark3 = 88;


        int total =
                mark1 + mark2 + mark3;


        /*
         * Without casting, integer division
         * will be performed.
         */

        double average1 = total / 3;


        /*
         * Casting total to double causes
         * floating-point division.
         */

        double average2 =
                (double) total / 3;


        System.out.println(
                "Total: " + total
        );

        System.out.println(
                "Average without casting: "
                        + average1
        );

        System.out.println(
                "Average with casting: "
                        + average2
        );
    }
}