public class IntegerLiteralsDemo {

    public static void main(String[] args) {

        /*
         * Java supports different forms
         * of integer literals.
         *
         * Decimal      - Base 10
         * Binary       - Base 2
         * Octal        - Base 8
         * Hexadecimal  - Base 16
         */


        // Decimal literal
        int decimalNumber = 25;

        /*
         * Binary literal starts with 0b or 0B.
         *
         * Binary 11001 = Decimal 25
         */
        int binaryNumber = 0b11001;

        /*
         * Octal literal starts with 0.
         *
         * Octal 31 = Decimal 25
         */
        int octalNumber = 031;

        /*
         * Hexadecimal literal starts with 0x or 0X.
         *
         * Hexadecimal 19 = Decimal 25
         */
        int hexadecimalNumber = 0x19;


        System.out.println(
                "Decimal value     : "
                + decimalNumber
        );

        System.out.println(
                "Binary value      : "
                + binaryNumber
        );

        System.out.println(
                "Octal value       : "
                + octalNumber
        );

        System.out.println(
                "Hexadecimal value : "
                + hexadecimalNumber
        );
    }
}