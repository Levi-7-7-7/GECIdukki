public class PrimitiveTypesDemo {

    public static void main(String[] args) {

        /*
         * Java has 8 primitive data types:
         *
         * 1. byte
         * 2. short
         * 3. int
         * 4. long
         * 5. float
         * 6. double
         * 7. char
         * 8. boolean
         */


        // ------------------------------
        // INTEGER TYPES
        // ------------------------------

        // Integer literal 25 is assigned to a byte variable
        byte age = 25;

        // Integer literal 2026 is assigned to a short variable
        short year = 2026;

        // By default, whole number literals are of type int
        int salary = 50000;

        /*
         * Long literals should use the suffix L.
         * Uppercase L is preferred because lowercase l
         * may look like the digit 1.
         */
        long population = 1400000000L;


        // ------------------------------
        // FLOATING-POINT TYPES
        // ------------------------------

        /*
         * Decimal literals are double by default.
         *
         * Therefore, F or f is required
         * for a float literal.
         */
        float temperature = (float)36.5;

        // Decimal literal is double by default
        double pi = 3.1415926535;


        // ------------------------------
        // CHARACTER TYPE
        // ------------------------------

        /*
         * A character literal is written
         * inside single quotation marks.
         */
        char grade = 'A';


        // ------------------------------
        // BOOLEAN TYPE
        // ------------------------------

        /*
         * Boolean literals are:
         *
         * true
         * false
         */
        boolean isJavaEasy = true;


        // Displaying the values

        System.out.println("byte value    : " + age);
        System.out.println("short value   : " + year);
        System.out.println("int value     : " + salary);
        System.out.println("long value    : " + population);
        System.out.println("float value   : " + temperature);
        System.out.println("double value  : " + pi);
        System.out.println("char value    : " + grade);
        System.out.println("boolean value : " + isJavaEasy);
    }
}