public class StringComparisonDemo {

    public static void main(String[] args) {

        /*
         * str1 and str2 are string literals.
         *
         * Java stores string literals in a special
         * memory area called String Constant Pool.
         *
         * If the same literal already exists,
         * Java reuses it.
         */

        String str1 = "Java";
        String str2 = "Java";

        /*
         * str3 is created using new.
         *
         * This creates a new String object
         * in heap memory.
         */

        String str3 = new String("Java");


        /*
         * == compares references.
         *
         * It checks whether two variables point
         * to the same object in memory.
         */

        System.out.println("str1 == str2 : " + (str1 == str2));

        System.out.println("str1 == str3 : " + (str1 == str3));


        /*
         * equals() compares contents.
         *
         * It checks whether the actual text
         * inside the String objects is the same.
         */

        System.out.println("str1.equals(str2) : " + str1.equals(str2));

        System.out.println("str1.equals(str3) : " + str1.equals(str3));
    }
}