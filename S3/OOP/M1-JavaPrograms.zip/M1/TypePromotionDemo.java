public class TypePromotionDemo {

    public static void main(String[] args) {

        /*
         * During arithmetic operations,
         * byte, short and char values are
         * automatically promoted to int.
         */

        byte a = 10;

        byte b = 20;


        /*
         * The following is invalid:
         *
         * byte result = a + b;
         *
         * a + b produces an int result.
         */


        int result = a + b;


        System.out.println(
                "a = " + a
        );

        System.out.println(
                "b = " + b
        );

        System.out.println(
                "a + b = " + result
        );


        /*
         * Explicit cast is required
         * if the result must be stored
         * in a byte variable.
         */

        byte byteResult =
                (byte) (a + b);


        System.out.println(
                "byte result = " + byteResult
        );
    }
}