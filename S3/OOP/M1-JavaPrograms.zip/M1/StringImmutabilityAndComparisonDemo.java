public class StringImmutabilityAndComparisonDemo {

    public static void main(String[] args) {

        // =====================================
        // PART 1: STRING IMMUTABILITY
        // =====================================

        String college = "GEC";

        System.out.println("--- STRING IMMUTABILITY ---");

        System.out.println("Original String: " + college);

        /*
         * This statement creates a new String,
         * but we are not storing it anywhere.
         *
         * Therefore, college still refers to "GEC".
         */

        college.concat(" Idukki");

        System.out.println(
                "After concat without assignment: " + college
        );

        /*
         * Now the new String is assigned back
         * to the same reference variable.
         *
         * The original String "GEC" is not changed.
         * Instead, college now refers to a new String.
         */

        college = college.concat(" Idukki");

        System.out.println(
                "After concat with assignment: " + college
        );


        // =====================================
        // PART 2: == AND equals()
        // =====================================

        System.out.println("\n--- STRING COMPARISON ---");

        String s1 = "Java";
        String s2 = "Java";
        String s3 = new String("Java");

        /*
         * s1 and s2 refer to the same object
         * from the String Constant Pool.
         */

        System.out.println("s1 == s2 : " + (s1 == s2));

        /*
         * s3 refers to a different object
         * created using new.
         */

        System.out.println("s1 == s3 : " + (s1 == s3));

        /*
         * equals() compares actual content.
         */

        System.out.println("s1.equals(s2) : " + s1.equals(s2));

        System.out.println("s1.equals(s3) : " + s1.equals(s3));
    }
}