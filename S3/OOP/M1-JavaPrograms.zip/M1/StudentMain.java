class Student
{ 
	String name;
	int rollNumber;
	
	// code to initialize
	Student( sName, sRNo)
	{
		name = sName;
		rollNumber = sRNo ;
	}
	
	void examRegistration()
	{
		// add code to perform exam registration
	}
	
	void display()
	{
		System.out.println("Name:" + name);
		System.out.println("Roll No:" + rollNumber);
	}
}

class StudentMain
{
	public static void main(String args[])
	{
		System.out.println("Main");
	
	}

}