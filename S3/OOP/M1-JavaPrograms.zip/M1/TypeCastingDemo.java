public class TypeCastingDemo {

    public static void main(String[] args) {

        // ---------------------------------
        // WIDENING CASTING
        // ---------------------------------

        int number = 50;

        /*
         * int is automatically converted
         * into double.
         */

        double doubleNumber = number;


        System.out.println("WIDENING CASTING");

        System.out.println(
                "int value    : " + number
        );

        System.out.println(
                "double value : " + doubleNumber
        );


        // ---------------------------------
        // NARROWING CASTING
        // ---------------------------------

        double price = 99.95;

        /*
         * Explicit cast is required
         * to convert double into int.
         */

        int integerPrice = (int) price;


        System.out.println("\nNARROWING CASTING");

        System.out.println(
                "double value : " + price
        );

        System.out.println(
                "int value    : " + integerPrice
        );
    }
}