public class ContinueAndLabeledContinueDemo {

    public static void main(String[] args) {

        /*
         * PART 1: Normal continue
         *
         * continue is used to skip the current iteration
         * and move to the next iteration of the loop.
         */

        System.out.println("--- Normal continue example ---");

        for (int i = 1; i <= 10; i++) {

            if (i == 5) {
                /*
                 * When i becomes 5, this iteration is skipped.
                 * The statement below will not be executed for i = 5.
                 */
                continue;
            }

            System.out.println("i = " + i);
        }

        System.out.println("Number 5 was skipped");


        /*
         * PART 2: Labeled continue
         *
         * A labeled continue is used to skip the current
         * iteration of a specific outer loop.
         *
         * It is mainly useful in nested loops.
         */

        System.out.println("\n--- Labeled continue example ---");

        outerLoop:
        for (int row = 1; row <= 3; row++) {

            for (int col = 1; col <= 3; col++) {

                if (row == 2 && col == 2) {

                    /*
                     * Normal continue would skip only
                     * the current iteration of the inner loop.
                     *
                     * But continue outerLoop skips the
                     * remaining part of the current row
                     * and moves to the next row.
                     */

                    continue outerLoop;
                }

                System.out.println("row = " + row + ", col = " + col);
            }
        }

        System.out.println("Skipped remaining columns of row 2 using labeled continue");
    }
}