import java.util.ArrayList;

public class WhyWrapperClass {

    public static void main(String[] args) {

        /*
         * Primitive variable
         */

        int number = 10;

        System.out.println(
                "Primitive value: " + number
        );


        /*
         * Integer is the wrapper class for int.
         *
         * It represents an int value
         * as an object.
         */

        Integer wrapperNumber = 10;

        System.out.println(
                "Wrapper value: " + wrapperNumber
        );


        /*
         * NEED 1:
         *
         * Collections such as ArrayList
         * require objects.
         */

        ArrayList<Integer> numbers =
                new ArrayList<Integer>();

        numbers.add(10);
        numbers.add(20);
        numbers.add(30);

        System.out.println(
                "ArrayList: " + numbers
        );


        /*
         * NEED 2:
         *
         * Wrapper classes provide
         * useful conversion methods.
         */

        String text = "500";

        int value =
                Integer.parseInt(text);

        System.out.println(
                "Converted value: " + value
        );


        /*
         * NEED 3:
         *
         * Wrapper types can represent null.
         */

        Integer mark = null;

        System.out.println(
                "Mark: " + mark
        );


        /*
         * NEED 4:
         *
         * Wrapper classes provide
         * constants and utility methods.
         */

        System.out.println(
                "Maximum int value: "
                        + Integer.MAX_VALUE
        );

        System.out.println(
                "Binary of 10: "
                        + Integer.toBinaryString(10)
        );
    }
}