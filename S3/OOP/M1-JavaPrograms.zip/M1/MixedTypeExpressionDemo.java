public class MixedTypeExpressionDemo {

    public static void main(String[] args) {

        int number = 10;

        double value = 5.5;


        /*
         * One operand is int.
         * The other operand is double.
         *
         * int is automatically promoted
         * to double before addition.
         */

        double result = number + value;


        System.out.println(
                "Integer value : " + number
        );

        System.out.println(
                "Double value  : " + value
        );

        System.out.println(
                "Result        : " + result
        );
    }
}