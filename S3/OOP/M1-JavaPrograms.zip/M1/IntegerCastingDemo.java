public class IntegerCastingDemo {

    public static void main(String[] args) {

        int number = 100;


        /*
         * int to byte is narrowing.
         *
         * Explicit cast is required.
         */

        byte byteValue = (byte) number;


        /*
         * int to short is narrowing.
         *
         * Explicit cast is required.
         */

        short shortValue = (short) number;


        /*
         * int to long is widening.
         *
         * No explicit cast is required.
         */

        long longValue = number;


        System.out.println(
                "Original int : " + number
        );

        System.out.println(
                "byte value   : " + byteValue
        );

        System.out.println(
                "short value  : " + shortValue
        );

        System.out.println(
                "long value   : " + longValue
        );
    }
}