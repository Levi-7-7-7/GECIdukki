public class CastingDataLossDemo {

    public static void main(String[] args) {

        /*
         * Narrowing conversion may result
         * in loss of data.
         */


        // --------------------------------
        // Loss of fractional part
        // --------------------------------

        double value = 98.75;

        int integerValue = (int) value;


        System.out.println(
                "Original double : " + value
        );

        System.out.println(
                "After casting   : " + integerValue
        );


        // --------------------------------
        // Value outside byte range
        // --------------------------------

        int number = 130;

        /*
         * byte range:
         *
         * -128 to 127
         */

        byte byteValue = (byte) number;


        System.out.println(
                "\nOriginal int : " + number
        );

        System.out.println(
                "After casting to byte : " + byteValue
        );
    }
}