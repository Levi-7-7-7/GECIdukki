public class ShiftOperatorDemo {

    public static void main(String[] args) {

        /*
         * Shift operators work on binary bits.
         *
         * <<  : Left shift
         * >>  : Signed right shift
         * >>> : Unsigned right shift
         */

        int number = 8;

        System.out.println("Original number: " + number);
        System.out.println("Binary form    : " + Integer.toBinaryString(number));

        /*
         * LEFT SHIFT <<
         *
         * Bits are shifted to the left.
         * Empty positions on the right are filled with 0.
         *
         * 8 << 1 means:
         * 8 * 2 = 16
         */

        int leftShift = number << 1;

        System.out.println("\n8 << 1 = " + leftShift);
        System.out.println("Binary  : " + Integer.toBinaryString(leftShift));

        /*
         * SIGNED RIGHT SHIFT >>
         *
         * Bits are shifted to the right.
         * The sign bit is preserved.
         *
         * For positive numbers, empty positions
         * on the left are filled with 0.
         *
         * 8 >> 1 means:
         * 8 / 2 = 4
         */

        int rightShift = number >> 1;

        System.out.println("\n8 >> 1 = " + rightShift);
        System.out.println("Binary : " + Integer.toBinaryString(rightShift));

        /*
         * UNSIGNED RIGHT SHIFT >>>
         *
         * Bits are shifted to the right.
         * Empty positions on the left are always filled with 0.
         *
         * For positive numbers, >> and >>> give same result.
         */

        int unsignedRightShift = number >>> 1;

        System.out.println("\n8 >>> 1 = " + unsignedRightShift);
        System.out.println("Binary  : " + Integer.toBinaryString(unsignedRightShift));


        /*
         * Difference between >> and >>>
         * is clearly visible for negative numbers.
         */

        int negativeNumber = -8;

        System.out.println("\nNegative number: " + negativeNumber);
        System.out.println("Binary form    : " + Integer.toBinaryString(negativeNumber));

        /*
         * Signed right shift preserves the sign.
         * So the result remains negative.
         */

        int signedResult = negativeNumber >> 1;

        System.out.println("\n-8 >> 1 = " + signedResult);
        System.out.println("Binary  : " + Integer.toBinaryString(signedResult));

        /*
         * Unsigned right shift fills 0 on the left.
         * So the result becomes a large positive number.
         */

        int unsignedResult = negativeNumber >>> 1;

        System.out.println("\n-8 >>> 1 = " + unsignedResult);
        System.out.println("Binary   : " + Integer.toBinaryString(unsignedResult));
    }
}