public class CharacterLiteralsDemo {

    public static void main(String[] args) {

        /*
         * A character literal is written
         * using single quotation marks.
         */

        char letter = 'A';

        char digit = '5';

        char symbol = '@';


        System.out.println("Letter : " + letter);
        System.out.println("Digit  : " + digit);
        System.out.println("Symbol : " + symbol);


        /*
         * Java characters use Unicode.
         *
         * Unicode values can be written
         * using \u followed by four
         * hexadecimal digits.
         */

        char unicodeLetter = '\u0041';

        /*
         * Unicode 0041 represents A.
         */

        System.out.println(
                "Unicode Character: "
                + unicodeLetter
        );


        // Escape character literals

        char newLine = '\n';

        char tab = '\t';

        char singleQuote = '\'';

        char backslash = '\\';


        System.out.println("Java" + newLine + "Programming");

        System.out.println("Name" + tab + "Mark");

        System.out.println(
                "Single Quote: " + singleQuote
        );

        System.out.println(
                "Backslash: " + backslash
        );
    }
}