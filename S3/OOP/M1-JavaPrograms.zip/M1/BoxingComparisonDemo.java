public class BoxingComparisonDemo {

    public static void main(String[] args) {

        int number = 50;


        /*
         * MANUAL BOXING
         *
         * Primitive value is explicitly
         * converted into a wrapper object.
         */

        Integer value1 =
                Integer.valueOf(number);


        /*
         * AUTOBOXING
         *
         * Java automatically converts
         * int into Integer.
         */

        Integer value2 = number;


        System.out.println(
                "Manual Boxing : " + value1
        );

        System.out.println(
                "Autoboxing    : " + value2
        );
    }
}