public class PrimitiveLiteralDemo {

    public static void main(String[] args) {

        /*
         * INTEGER LITERALS
         */

        byte age = 25;
        short year = 2026;
        int decimal = 25;
        int binary = 0b11001;
        int octal = 031;
        int hexadecimal = 0x19;
        long population = 1_400_000_000L;


        /*
         * FLOATING-POINT LITERALS
         */
        float temperature = 36.5F;
        double pi = 3.14159;
        double scientificValue = 1.5e3;


        /*
         * CHARACTER LITERALS
         */

        char grade = 'A';
        char digit = '5';
        char unicodeCharacter = '\u0041';


        /*
         * BOOLEAN LITERALS
         */

        boolean isJavaEasy = true;
        boolean isRaining = false;


        // Display Integer Types

        System.out.println("--- INTEGER TYPES ---");

        System.out.println("byte        : " + age);
        System.out.println("short       : " + year);
        System.out.println("decimal     : " + decimal);
        System.out.println("binary      : " + binary);
        System.out.println("octal       : " + octal);
        System.out.println("hexadecimal : " + hexadecimal);
        System.out.println("long        : " + population);


        // Display Floating-Point Types

        System.out.println("\n--- FLOATING POINT TYPES ---");

        System.out.println("float      : " + temperature);
        System.out.println("double     : " + pi);
        System.out.println("scientific : " + scientificValue);


        // Display Character Types

        System.out.println("\n--- CHARACTER TYPE ---");

        System.out.println("Character : " + grade);
        System.out.println("Digit     : " + digit);
        System.out.println("Unicode   : " + unicodeCharacter);


        // Display Boolean Types

        System.out.println("\n--- BOOLEAN TYPE ---");
        System.out.println("Java Easy? : " + isJavaEasy);
        System.out.println("Raining?   : " + isRaining);
    }
}