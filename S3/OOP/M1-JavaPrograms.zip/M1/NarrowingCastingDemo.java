public class NarrowingCastingDemo {

    public static void main(String[] args) {

        /*
         * NARROWING TYPE CASTING
         *
         * A value of a larger data type is
         * converted into a smaller data type.
         *
         * Java does not perform this automatically.
         *
         * Explicit casting is required.
         */

        double doubleValue = 125.75;


        /*
         * The following statement is invalid:
         *
         * int intValue = doubleValue;
         *
         * double cannot be automatically
         * converted to int.
         */


        // Explicit type casting

        int intValue = (int) doubleValue;


        System.out.println(
                "Original double value : " + doubleValue
        );

        System.out.println(
                "Converted int value   : " + intValue
        );
    }
}