public class AutoboxingDemo {

    public static void main(String[] args) {

        /*
         * AUTOBOXING
         *
         * Automatic conversion of a primitive value
         * into its corresponding wrapper object.
         */

        int number = 100;

        // int is automatically converted to Integer
        Integer wrapperNumber = number;


        /*
         * UNBOXING
         *
         * Automatic conversion of a wrapper object
         * into its corresponding primitive value.
         */

        Integer marksObject = 85;

        // Integer is automatically converted to int
        int marks = marksObject;


        System.out.println(
                "Primitive value : " + number
        );

        System.out.println(
                "Wrapper value   : " + wrapperNumber
        );

        System.out.println(
                "Unboxed value   : " + marks
        );
    }
}