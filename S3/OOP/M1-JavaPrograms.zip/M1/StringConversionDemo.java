public class StringConversionDemo {

    public static void main(String[] args) {

        /*
         * Data obtained from keyboard,
         * files or web forms is often
         * available as String.
         */

        String ageText = "25";
        String salaryText = "45000.50";
        String statusText = "true";


        /*
         * Convert String to int
         */

        int age =
                Integer.parseInt(ageText);


        /*
         * Convert String to double
         */

        double salary =
                Double.parseDouble(salaryText);


        /*
         * Convert String to boolean
         */

        boolean status =
                Boolean.parseBoolean(statusText);


        System.out.println(
                "Age: " + age
        );

        System.out.println(
                "Salary: " + salary
        );

        System.out.println(
                "Status: " + status
        );


        /*
         * Now converted values can
         * participate in operations.
         */

        int nextYearAge = age + 1;

        double increasedSalary =
                salary + 5000;


        System.out.println(
                "Age Next Year: " + nextYearAge
        );

        System.out.println(
                "Increased Salary: "
                        + increasedSalary
        );
    }
}