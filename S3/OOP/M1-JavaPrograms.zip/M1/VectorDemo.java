import java.util.Vector;

public class VectorDemo {

    public static void main(String[] args) {

        /*
         * Vector is a dynamic array.
         *
         * Normal arrays have fixed size.
         * But Vector can grow or shrink during program execution.
         */

        // Creating a Vector to store student names
        Vector<String> students = new Vector<String>();

        // Adding elements to the Vector
        students.add("Arun");
        students.add("Anu");
        students.add("Rahul");
        students.add("Meera");

        System.out.println("Initial Vector: " + students);

        // Displaying size and capacity
        System.out.println("Size of Vector: " + students.size());
        System.out.println("Capacity of Vector: " + students.capacity());

        /*
         * Accessing elements
         * Index starts from 0.
         */

        System.out.println("First student: " + students.get(0));
        System.out.println("Second student: " + students.get(1));

        /*
         * Adding an element at a specific position
         */

        students.add(2, "John");

        System.out.println("After adding John at index 2: " + students);

        /*
         * Removing an element
         */

        students.remove("Rahul");

        System.out.println("After removing Rahul: " + students);

        /*
         * Checking whether an element exists
         */

        if (students.contains("Anu")) {
            System.out.println("Anu is present in the Vector");
        } else {
            System.out.println("Anu is not present in the Vector");
        }

        /*
         * Traversing the Vector using for loop
         */

        System.out.println("\nStudents using normal for loop:");

        for (int i = 0; i < students.size(); i++) {
            System.out.println(students.get(i));
        }

        /*
         * Traversing the Vector using enhanced for loop
         */

        System.out.println("\nStudents using enhanced for loop:");

        for (String student : students) {
            System.out.println(student);
        }

        /*
         * Updating an element
         */

        students.set(0, "Arjun");

        System.out.println("\nAfter updating first student: " + students);

        /*
         * Removing all elements
         */

        students.clear();

        System.out.println("After clearing Vector: " + students);
        System.out.println("Is Vector empty? " + students.isEmpty());
    }
}